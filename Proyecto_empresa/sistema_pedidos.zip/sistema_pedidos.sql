-- Creación de la base de datos
CREATE DATABASE sistema_pedidos;
USE sistema_pedidos;

CREATE TABLE `detalles_pedido` (
  `idDetalle` int(11) NOT NULL,
  `idPedido` int(11) NOT NULL,
  `idProducto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL DEFAULT 1,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `detalles_pedido_ingredientes` (
  `idDetalle` int(11) NOT NULL,
  `idIngrediente` int(11) NOT NULL,
  `modificacion` enum('agregado','removido','extra') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `ingredientes` (
  `idIngrediente` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `categoria` enum('proteína','queso','vegetal','salsa','extra','pan','bebida') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `inventario` (
  `idInventario` int(11) NOT NULL,
  `idIngrediente` int(11) NOT NULL,
  `cantidadDisponible` int(11) NOT NULL DEFAULT 0,
  `estado` enum('disponible','bajo','agotado') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `metodos_pago` (
  `idPago` int(11) NOT NULL,
  `idPedido` int(11) NOT NULL,
  `metodo` enum('tarjeta','efectivo','paypal','apple_pay','google_pay') NOT NULL,
  `monto` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `pedidos` (
  `idPedido` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `fecha` timestamp NULL DEFAULT current_timestamp(),
  `fechaEntregaProgramada` datetime DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `estado` enum('pendiente','preparando','en camino','entregado','cancelado') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `productos` (
  `idProducto` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precioVenta` decimal(10,2) NOT NULL,
  `precioProduccion` decimal(10,2) NOT NULL,
  `oferta` tinyint(1) DEFAULT 0,
  `precioOferta` decimal(10,2) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `fechaCreat` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `productos_ingredientes` (
  `idProducto` int(11) NOT NULL,
  `idIngrediente` int(11) NOT NULL,
  `cantidadNecesaria` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `repartidores` (
  `idRepartidor` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `estado` enum('disponible','ocupado','fuera de servicio') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `reportes` (
  `idReporte` int(11) NOT NULL,
  `tipo` enum('ventas','productos_mas_vendidos','tiempo_entrega','historial_pedidos','inventario') NOT NULL,
  `fechaGeneracion` timestamp NULL DEFAULT current_timestamp(),
  `datos` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `seguimiento_pedidos` (
  `idSeguimiento` int(11) NOT NULL,
  `idPedido` int(11) NOT NULL,
  `idRepartidor` int(11) NOT NULL,
  `estado` enum('pendiente','en camino','entregado') NOT NULL,
  `ubicacion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `usuarios` (
  `idUsuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('cliente','repartidor','admin') NOT NULL,
  `create_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `detalles_pedido`
  ADD PRIMARY KEY (`idDetalle`),
  ADD KEY `idPedido` (`idPedido`),
  ADD KEY `idProducto` (`idProducto`);

ALTER TABLE `detalles_pedido_ingredientes`
  ADD PRIMARY KEY (`idDetalle`,`idIngrediente`),
  ADD KEY `idIngrediente` (`idIngrediente`);

ALTER TABLE `ingredientes`
  ADD PRIMARY KEY (`idIngrediente`);

ALTER TABLE `inventario`
  ADD PRIMARY KEY (`idInventario`),
  ADD KEY `idIngrediente` (`idIngrediente`);

ALTER TABLE `metodos_pago`
  ADD PRIMARY KEY (`idPago`),
  ADD KEY `idPedido` (`idPedido`);

ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`idPedido`),
  ADD KEY `idUsuario` (`idUsuario`);

ALTER TABLE `productos`
  ADD PRIMARY KEY (`idProducto`);

ALTER TABLE `productos_ingredientes`
  ADD PRIMARY KEY (`idProducto`,`idIngrediente`),
  ADD KEY `idIngrediente` (`idIngrediente`);

ALTER TABLE `repartidores`
  ADD PRIMARY KEY (`idRepartidor`);

ALTER TABLE `reportes`
  ADD PRIMARY KEY (`idReporte`);

ALTER TABLE `seguimiento_pedidos`
  ADD PRIMARY KEY (`idSeguimiento`),
  ADD KEY `idPedido` (`idPedido`),
  ADD KEY `idRepartidor` (`idRepartidor`);

ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idUsuario`),
  ADD UNIQUE KEY `correo` (`email`);

ALTER TABLE `detalles_pedido`
  MODIFY `idDetalle` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `ingredientes`
  MODIFY `idIngrediente` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `inventario`
  MODIFY `idInventario` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `metodos_pago`
  MODIFY `idPago` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `pedidos`
  MODIFY `idPedido` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `productos`
  MODIFY `idProducto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

ALTER TABLE `repartidores`
  MODIFY `idRepartidor` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `reportes`
  MODIFY `idReporte` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `seguimiento_pedidos`
  MODIFY `idSeguimiento` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `usuarios`
  MODIFY `idUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `detalles_pedido`
  ADD CONSTRAINT `detalles_pedido_ibfk_1` FOREIGN KEY (`idPedido`) REFERENCES `pedidos` (`idPedido`) ON DELETE CASCADE,
  ADD CONSTRAINT `detalles_pedido_ibfk_2` FOREIGN KEY (`idProducto`) REFERENCES `productos` (`idProducto`) ON DELETE CASCADE;

ALTER TABLE `detalles_pedido_ingredientes`
  ADD CONSTRAINT `detalles_pedido_ingredientes_ibfk_1` FOREIGN KEY (`idDetalle`) REFERENCES `detalles_pedido` (`idDetalle`) ON DELETE CASCADE,
  ADD CONSTRAINT `detalles_pedido_ingredientes_ibfk_2` FOREIGN KEY (`idIngrediente`) REFERENCES `ingredientes` (`idIngrediente`) ON DELETE CASCADE;

ALTER TABLE `inventario`
  ADD CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`idIngrediente`) REFERENCES `ingredientes` (`idIngrediente`) ON DELETE CASCADE;

ALTER TABLE `metodos_pago`
  ADD CONSTRAINT `metodos_pago_ibfk_1` FOREIGN KEY (`idPedido`) REFERENCES `pedidos` (`idPedido`) ON DELETE CASCADE;

ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuarios` (`idUsuario`) ON DELETE CASCADE;

ALTER TABLE `productos_ingredientes`
  ADD CONSTRAINT `productos_ingredientes_ibfk_1` FOREIGN KEY (`idProducto`) REFERENCES `productos` (`idProducto`) ON DELETE CASCADE,
  ADD CONSTRAINT `productos_ingredientes_ibfk_2` FOREIGN KEY (`idIngrediente`) REFERENCES `ingredientes` (`idIngrediente`) ON DELETE CASCADE;

ALTER TABLE `seguimiento_pedidos`
  ADD CONSTRAINT `seguimiento_pedidos_ibfk_1` FOREIGN KEY (`idPedido`) REFERENCES `pedidos` (`idPedido`) ON DELETE CASCADE,
  ADD CONSTRAINT `seguimiento_pedidos_ibfk_2` FOREIGN KEY (`idRepartidor`) REFERENCES `repartidores` (`idRepartidor`) ON DELETE CASCADE;
COMMIT;